package com.example.lab5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PostReply extends AppCompatActivity {
    DatabaseReference findId, databaseReference;
    ListView postView;
    ArrayAdapter<String> arrayAdapter;
    ArrayList<String> arrayList = new ArrayList<>();
    private String id, post;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_reply);

        Bundle b = getIntent().getExtras();
        post = b.getString("content");
        TextView tv = findViewById(R.id.Postingid);
        tv.setText(post);

        //wire up the button
        ImageButton btn = findViewById(R.id.imageButton3);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toy = new Intent(PostReply.this, PostList.class);
                startActivity(toy);
            }
        });
        // Start Find realID
        findId = FirebaseDatabase.getInstance().getReference("Messages");
        findId.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren())
                {
                    Messages mess = ds.getValue(Messages.class);
                    String check = mess.getContent();
                    if(check.compareTo(post) == 0)
                    {
                        id = ds.getKey();
                        databaseReference = FirebaseDatabase.getInstance().getReference("Comments/" + id);
                        postView = findViewById(R.id.Replylist);
                        arrayAdapter = new ArrayAdapter<>(PostReply.this, android.R.layout.simple_list_item_1, arrayList);
                        databaseReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for(DataSnapshot ds: dataSnapshot.getChildren())
                                {
                                    String mess = ds.getValue(Messages.class).getContent();
                                    arrayList.add(mess);
                                }
                                postView.setAdapter(arrayAdapter);
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        break;
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        ImageButton btn_delete= findViewById((R.id.imageButton4));
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToDeleteActivity();
            }
        });
        Button btn_reply= findViewById((R.id.ReplyPosting));
        btn_reply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ReplyActivity();
            }
        });
    }
    private void goToDeleteActivity() {
        Intent intent = new Intent(this, DeletePost.class);
        Bundle extras = new Bundle();
        extras.putString("id", id);
        intent.putExtras(extras);
        startActivity(intent);
    }
    private void ReplyActivity()
    {
        Intent intent = new Intent(this, ReplyPost.class);
        Bundle extras = new Bundle();
        extras.putString("id", id);
        extras.putString("post", post);
        intent.putExtras(extras);
        startActivity(intent);
    }
}
