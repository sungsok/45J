package com.example.lab5;

public class Messages {
    private Long score;
    private String content;

    public Messages() {
    }
    public Messages(Long score, String content) {
        this.score = score;
        this.content = content;
    }

    public Long getScore() {
        return score;
    }

    public void setScore(Long score) {
        this.score = score;
    }
    public void downScore() {
        this.score = this.score - 1;
    }
    public void upScore() {
        this.score = this.score + 1;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String toString() {
        return this.content + ", scored: " + this.score;
    }
}
