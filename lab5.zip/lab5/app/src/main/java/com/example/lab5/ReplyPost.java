package com.example.lab5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ReplyPost extends AppCompatActivity {
    private DatabaseReference myRef;
    private long currentID;
    private String post, id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reply_post);

        Bundle b = getIntent().getExtras();
        id = b.getString("id");
        post = b.getString("post");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Comments/" + id);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                    currentID = (dataSnapshot.getChildrenCount());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        ImageButton btn_home = findViewById(R.id.btn_home3);
        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToPostActivity();
            }
        });

        Button btn_post = findViewById(R.id.btn_reply);
        btn_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addReply(v);
            }
        });
    }

    public void addReply(View view)
    {
        EditText editReply = findViewById(R.id.editReply);
        String content = editReply.getText().toString();
        Messages mess = new Messages((long) 0, content);
        if( content.length() > 0 )
        {
            myRef.child(String.valueOf(currentID + 1)).setValue(mess);
            Toast.makeText(this, content + " successfully added.",
                    Toast.LENGTH_LONG).show();
        }
        editReply.setText("");
        Intent intent = new Intent(this, PostReply.class);
        startActivity(intent);
    }

    private void goToPostActivity() {
        Intent intent = new Intent(this, PostReply.class);
        Bundle extras = new Bundle();
        extras.putString("id", id);
        extras.putString("post", post);
        intent.putExtras(extras);
        startActivity(intent);
    }
}
