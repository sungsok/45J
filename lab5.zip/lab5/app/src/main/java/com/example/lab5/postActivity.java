package com.example.lab5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class postActivity extends AppCompatActivity {

    private DatabaseReference myRef;
    private String nextId = "M0";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Messages");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    String count = null;
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        count = ds.getKey().substring(1);
                    }
                    nextId = "M" + (Integer.parseInt(count) + 1);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Button btn_post = findViewById(R.id.postbutton);
        btn_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMessage(v);
            }
        });
        ImageButton btn_back=findViewById(R.id.imageButton);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toy= new Intent (postActivity.this, PostList.class);
                startActivity(toy);

            }
        });
    }

    public void addMessage(View view)
    {
        EditText editText = findViewById(R.id.editText3);
        String content = editText.getText().toString();
        Messages mess = new Messages((long) 0, content);
        if( content.length() > 0 )
        {
            myRef.child(String.valueOf(nextId)).setValue(mess);
            Toast.makeText(this, content + " successfully added.",
                    Toast.LENGTH_LONG).show();
        }
        editText.setText("");
        Intent intent = new Intent(this, PostList.class);
        startActivity(intent);
    }
}
